#version 150

precision highp float;








#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void f_691eae02(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_f5592597() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_5e8a4e4f(inout vec4 vertex) {
    f_691eae02(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_f5592597();
    }
    finalize();
}



void f_6dd42525() {
    vertexColor=hue(gl_Position.x+GameTime*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_cb0112bb() {
    gl_Position.y+=sin(GameTime*12000.+(gl_Position.x*6)) / 150.;
}

void f_85bb13b3(inout vec4 vertex) {
    f_691eae02(vertex);
    f_6dd42525();
    finalize();
}

void f_9a700407(inout vec4 vertex) {
    f_691eae02(vertex);
    f_f5592597();
    f_cb0112bb();
    finalize();
}

void f_68b03142(inout vec4 vertex) {
    f_691eae02(vertex);
    f_cb0112bb();
    f_6dd42525();
    finalize();
}

void f_52ed97d2(inout vec4 vertex) {
    f_f5592597();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(GameTime*12000. / 4)*.1;
            vertex.y+=max(cos(GameTime*12000. / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(GameTime*12000. / 4)*3;
            vertex.y-=max(cos(GameTime*12000. / 4)*4, 0.);
        }
    }
    f_691eae02(vertex);
    finalize();
}

void f_e27dbaad(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(GameTime*12000. / 4)*.1;
            vertex.y+=max(cos(GameTime*12000. / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(GameTime*12000. / 4)*3;
            vertex.y-=max(cos(GameTime*12000. / 4)*4, 0.);
        }
    }
    f_6dd42525();
    f_691eae02(vertex);
    finalize();
}

void f_ca189bbd(inout vec4 vertex, float speed) {
    f_691eae02(vertex);
    float blink=abs(sin(GameTime*12000.*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_e6c25e6b(inout vec4 vertex) {
    f_691eae02(vertex);
    f_f5592597();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_5e8a4e4f(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_f5592597();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_691eae02(vertex);
            f_f5592597();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_9a700407(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_9a700407(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_52ed97d2(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_52ed97d2(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_ca189bbd(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_e6c25e6b(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_85bb13b3(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_9a700407(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_68b03142(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_52ed97d2(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_e27dbaad(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_ca189bbd(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_85bb13b3(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_9a700407(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_68b03142(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_52ed97d2(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_e27dbaad(vertex);
        return;
    }
    

    
    f_691eae02(vertex);
    f_f5592597();
    finalize();
}